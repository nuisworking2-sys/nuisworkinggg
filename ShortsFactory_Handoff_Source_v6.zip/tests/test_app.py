import json, sys, time
from pathlib import Path
from fastapi.testclient import TestClient
sys.path.insert(0,str(Path(__file__).parents[1]/'server'))
import app as webapp
from script_utils import parse_srt

def test_parse_srt():
    cues=parse_srt('1\n00:00:00,000 --> 00:00:01,250\n안녕 세상\n\n2\n00:00:01.250 --> 00:00:02.000\n두 번째\n')
    assert cues==[{'text':'안녕 세상','start_ms':0,'end_ms':1250},{'text':'두 번째','start_ms':1250,'end_ms':2000}]

def test_folder_picker_decodes_korean_path(tmp_path,monkeypatch):
    monkeypatch.setattr(webapp,'DATA',tmp_path/'packages')
    (tmp_path/'packages').mkdir()
    monkeypatch.setattr(webapp,'_show_folder_dialog',lambda result_file:result_file.write_text(str(tmp_path/'한글 결과'),encoding='utf-8'))
    result=webapp.select_output_folder()
    assert result=={'cancelled':False,'path':str(tmp_path/'한글 결과')}

def test_results_are_written_directly_to_selected_folder(tmp_path,monkeypatch):
    monkeypatch.setattr(webapp,'DATA',tmp_path/'packages')
    results=tmp_path/'results';results.mkdir()
    def fake_image(_line,_context,out_path,**_kwargs):
        out_path.parent.mkdir(parents=True,exist_ok=True); out_path.write_bytes(b'png')
    monkeypatch.setattr(webapp,'generate_image_openai',fake_image)
    monkeypatch.setattr(webapp,'render_transparent_mov',lambda output,*_args,**_kwargs:output.write_bytes(b'mov'))
    client=TestClient(webapp.app)
    response=client.post('/api/transparent-packages',data={'settings_json':json.dumps({'output_dir':str(results)}),'openai_api_key':'secret-key'},files=[('script_files',('작업.txt','전체 대본','text/plain')),('srt_files',('작업.srt','1\n00:00:00,000 --> 00:00:01,000\n안녕/세상\n\n2\n00:00:01,000 --> 00:00:02,000\n안녕/세상\n','text/plain'))])
    assert response.status_code==200
    job_id=response.json()['job_id']
    for _ in range(100):
        status=client.get(f'/api/transparent-packages/{job_id}').json()
        if status['state'] in {'done','error'}:break
        time.sleep(.03)
    assert status['state']=='done',status
    assert 'secret-key' not in (tmp_path/'packages'/job_id/'status.json').read_text(encoding='utf-8')
    assert {p.relative_to(results).as_posix() for p in results.rglob('*') if p.is_file()}=={'작업/transparent_video.mov','작업/images/안녕 세상.png','작업/images/안녕 세상_2.png'}

def test_rejects_unmatched_names(tmp_path,monkeypatch):
    monkeypatch.setattr(webapp,'DATA',tmp_path/'packages')
    client=TestClient(webapp.app)
    response=client.post('/api/transparent-packages',data={'settings_json':json.dumps({'output_dir':str(tmp_path)}),'openai_api_key':'key'},files=[('script_files',('a.txt','x','text/plain')),('srt_files',('b.srt','x','text/plain'))])
    assert response.status_code==400
    assert '파일 이름이 같은' in response.json()['detail']
