# 다른 계정용 작업 인수인계

## 현재 목표

이 프로젝트는 같은 이름의 TXT/SRT 파일을 여러 쌍 업로드하면 각 작업을 순차 처리하는 Windows 로컬 숏폼 제작 도구다.

현재 출력 형식은 ZIP이나 MP4가 아니다. 사용자가 선택한 폴더 아래에 TXT/SRT의 공통 파일명으로 작업 폴더를 만들고 다음 파일을 생성 즉시 저장한다.

```text
선택한 폴더/
└─ 작업명/
   ├─ images/
   │  ├─ SRT 첫 대사.png
   │  └─ SRT 다음 대사.png
   └─ transparent_video.mov
```

- PNG: 배경 투명, 화면에 자막 텍스트 없음
- MOV: PNG들을 SRT 타이밍대로 연결한 무음 투명 영상
- MOV 코덱: ProRes 4444 (`yuva444p10le`)
- 음성 파일은 입력 및 출력에 필요 없음
- 결과 ZIP 다운로드도 사용하지 않음

## 핵심 동작

- TXT와 SRT는 확장자를 제외한 이름이 같아야 한 쌍으로 인식한다.
- 여러 쌍을 업로드하면 한 작업이 끝난 후 다음 작업을 순차 진행한다.
- PNG 파일명은 SRT 대사 내용으로 만들며, 중복 시 `_2`, `_3`을 붙인다.
- 각 PNG가 완성되는 즉시 선택한 결과 폴더에 저장한다.
- 모든 PNG가 완성되면 투명 MOV를 같은 작업 폴더에 저장한다.
- OpenAI API 키는 브라우저 입력값을 작업 메모리에서만 사용하고 결과/status 파일에 기록하지 않는다.
- 이미지/캐릭터 기본 프롬프트는 웃긴 숏폼 컷을 만들도록 `server/ai.py`에 정의되어 있다.

## 가장 최근 수정

Windows 폴더 선택 결과가 한글 경로에서 `%GOQ^TT`처럼 깨지던 문제를 수정했다. PowerShell 표준 출력으로 경로를 전달하지 않고 UTF-8 임시 파일에 기록한 뒤 Python이 읽는다. 관련 코드는 `server/app.py`의 `_show_folder_dialog`와 `/api/select-output-folder`다.

## 개발 실행

Windows PowerShell에서:

```powershell
cd server
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app:app --host 127.0.0.1 --port 8765
```

브라우저에서 `http://127.0.0.1:8765`를 연다. 영상 생성에는 PATH에 등록된 FFmpeg가 필요하다.

## 테스트

```powershell
python -m pip install pytest httpx
python -m pytest -q tests
```

현재 자동 테스트는 SRT 파싱, 한글 폴더 선택 경로, 선택 폴더 즉시 저장, TXT/SRT 불일치 거부를 검사한다.

## Windows 단일 EXE 빌드

PyInstaller와 `ffmpeg.exe`가 필요하다. `server` 폴더에서 아래 형식으로 실행한다.

```powershell
pyinstaller --noconfirm --clean --onefile `
  --name ShortsFactory_DirectSave `
  --add-data "static;static" `
  --add-binary "C:\path\to\ffmpeg.exe;." `
  --collect-all uvicorn --collect-all fastapi `
  desktop_launcher.py
```

`server/desktop_launcher.py`가 빈 포트를 선택하고 브라우저를 자동으로 연다. 실행 파일 옆의 `ShortsFactory_Data`에는 작업 상태와 업로드 임시 파일만 저장된다.

## 주요 파일

- `server/app.py`: API, 배치 큐, 폴더 선택, 직접 저장
- `server/ai.py`: 이미지 생성과 기본 프롬프트
- `server/script_utils.py`: SRT 파싱
- `server/video_utils.py`: 알파 채널 MOV 생성
- `server/static/index.html`: 화면
- `server/static/app.js`: 업로드, 실행, 진행률 표시
- `server/desktop_launcher.py`: Windows EXE 실행기
- `tests/test_app.py`: 회귀 테스트

## 다른 계정에서 이어가기

1. GitHub 저장소를 clone한다.
2. 이 문서를 새 대화에 첨부하거나 내용을 붙여 넣는다.
3. 새 작업 요청에 “`HANDOFF_KO.md`와 현재 코드를 먼저 읽고 이어서 수정해줘”라고 적는다.
4. API 키는 저장소에 올리지 말고 프로그램 화면에서 입력한다.

## 알려진 사항

- 기존 Render 웹 배포 파일은 남아 있지만, 현재 요구사항인 로컬 폴더 직접 저장은 Windows EXE에서 사용하는 기능이다.
- 브라우저 보안상 웹 서버가 임의의 PC 폴더에 직접 저장할 수 없으므로 클라우드 배포판과 로컬 EXE의 기능은 동일하지 않다.
- 이전 EXE를 여러 개 실행하면 8765 대신 8766 등 다음 포트를 사용한다. 테스트 전 이전 콘솔을 모두 종료하는 것이 좋다.
- `favicon.ico` 404 로그는 기능 오류가 아니다.

