from __future__ import annotations

import os
import socket
import sys
import threading
import time
import webbrowser
from pathlib import Path

import uvicorn
import app as web_app


def bundled_dir() -> Path:
    return Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))


def choose_port(start: int = 8765) -> int:
    for port in range(start, start + 100):
        with socket.socket() as sock:
            try:
                sock.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise RuntimeError("사용 가능한 로컬 포트를 찾지 못했습니다.")


def open_browser(url: str) -> None:
    time.sleep(1.2)
    webbrowser.open(url)


def main() -> None:
    root = bundled_dir()
    os.chdir(root)
    os.environ["PATH"] = str(root) + os.pathsep + os.environ.get("PATH", "")
    app_dir = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
    data_dir = app_dir / "ShortsFactory_Data"
    data_dir.mkdir(parents=True, exist_ok=True)
    os.environ["SHORTS_FACTORY_DATA"] = str(data_dir)
    port = choose_port()
    url = f"http://127.0.0.1:{port}"
    if os.getenv("SHORTS_FACTORY_NO_BROWSER") != "1":
        threading.Thread(target=open_browser, args=(url,), daemon=True).start()
    uvicorn.run(web_app.app, host="127.0.0.1", port=port, log_level="info")


if __name__ == "__main__":
    main()
